-- Tipsters table
create table if not exists public.tipsters (
  id text primary key,
  name text not null,
  img text not null default '',
  color text not null default 'gold',
  accuracy numeric not null default 0,
  odds numeric not null default 0,
  subscribers text not null default '0',
  betslips_count integer not null default 0,
  price integer not null default 0,
  platforms text[] not null default '{}',
  booking_codes jsonb not null default '{}',
  last_results text[] not null default '{}',
  countdown_hours integer not null default 6,
  countdown_mins integer not null default 0,
  countdown_secs integer not null default 0,
  is_top boolean not null default false,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.tipsters enable row level security;
drop policy if exists "tipsters_read" on public.tipsters;
create policy "tipsters_read" on public.tipsters for select using (true);
drop policy if exists "tipsters_write" on public.tipsters;
create policy "tipsters_write" on public.tipsters for all using (true) with check (true);
