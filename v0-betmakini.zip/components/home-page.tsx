"use client"

import { useState } from "react"
import { topTipsters, followTipsters } from "@/lib/data"
import { isSubscribed as checkSubscribed } from "@/lib/storage"
import BannerCarousel from "./banner-carousel"
import TipsterCard from "./tipster-card"

interface HomePageProps {
  onSubscribe: (name: string, img: string, id: string) => void
  onViewProfile: (id: string) => void
  refreshKey: number
}

export default function HomePage({ onSubscribe, onViewProfile, refreshKey }: HomePageProps) {
  const [search, setSearch] = useState("")

  const filterTipsters = (list: typeof topTipsters) =>
    list.filter((t) => t.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div key={refreshKey}>
      {/* Header */}
      <div className="flex justify-between items-center mx-auto max-w-[480px] px-4 pt-5 pb-3.5">
        <h1 className="text-[26px] font-black text-white flex items-center gap-2.5">
          Bet<span style={{ color: "#5DCEA8" }}>Makini</span>
        </h1>
        <button
          onClick={() => window.location.reload()}
          className="flex items-center justify-center cursor-pointer transition-all duration-300 hover:scale-110"
          style={{
            width: 40,
            height: 40,
            borderRadius: "50%",
            background: "rgba(93,206,168,0.1)",
            border: "2px solid rgba(93,206,168,0.3)",
          }}
          aria-label="Refresh"
        >
          <svg width={22} height={22} viewBox="0 0 24 24" fill="#5DCEA8">
            <path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z" />
          </svg>
        </button>
      </div>

      <BannerCarousel />

      {/* Search */}
      <div className="mx-auto max-w-[480px] px-4 mb-5">
        <div
          className="w-full flex items-center gap-3 rounded-[14px] transition-all duration-300"
          style={{
            padding: "14px 18px",
            background: "rgba(255,255,255,0.05)",
            border: "1.5px solid rgba(255,255,255,0.08)",
          }}
        >
          <svg width={20} height={20} viewBox="0 0 24 24" fill="currentColor" style={{ opacity: 0.6 }}>
            <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
          </svg>
          <input
            type="text"
            placeholder="Tafuta tipster..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-white text-[15px]"
            style={{ color: "#fff" }}
          />
        </div>
      </div>

      {/* Top Tipsters */}
      <div className="mx-auto max-w-[480px] px-4 mb-5">
        <div className="flex items-start gap-3">
          <div className="shrink-0 flex flex-col items-center gap-2 pt-5" style={{ width: 60 }}>
            <div
              className="flex items-center justify-center rounded-full"
              style={{
                width: 42,
                height: 42,
                background: "linear-gradient(135deg, rgba(255,100,100,0.15), rgba(200,50,50,0.2))",
                border: "2px solid #ff6b6b",
                animation: "targetShake 1.2s ease-in-out infinite",
              }}
            >
              <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#ff6b6b" strokeWidth={2}>
                <circle cx={12} cy={12} r={10} />
                <circle cx={12} cy={12} r={6} />
                <circle cx={12} cy={12} r={2} />
                <line x1={12} y1={2} x2={12} y2={6} />
                <line x1={12} y1={18} x2={12} y2={22} />
                <line x1={2} y1={12} x2={6} y2={12} />
                <line x1={18} y1={12} x2={22} y2={12} />
              </svg>
            </div>
            <div className="text-[11px] font-extrabold text-white text-center leading-tight">
              Top
              <br />
              Tipsters
            </div>
          </div>
          <div className="flex gap-2.5 overflow-x-auto hide-scrollbar pb-2 flex-1">
            {filterTipsters(topTipsters).map((t) => (
              <TipsterCard
                key={t.id}
                tipster={t}
                isSubscribed={checkSubscribed(t.name)}
                onSubscribe={onSubscribe}
                onViewProfile={onViewProfile}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Tipsters to Follow */}
      <div className="mx-auto max-w-[480px] px-4 mb-5">
        <div className="flex items-start gap-3">
          <div className="shrink-0 flex flex-col items-center gap-2 pt-5" style={{ width: 60 }}>
            <div
              className="flex items-center justify-center rounded-full"
              style={{
                width: 42,
                height: 42,
                background: "linear-gradient(135deg, rgba(93,206,168,0.2), rgba(0,150,100,0.25))",
                border: "2px solid #5DCEA8",
                animation: "verifiedGlow 2s ease-in-out infinite",
              }}
            >
              <svg width={22} height={22} viewBox="0 0 24 24" fill="#5DCEA8" style={{ animation: "checkPop 1.5s ease-in-out infinite" }}>
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
              </svg>
            </div>
            <div className="text-[11px] font-extrabold text-white text-center leading-tight">
              Tipsters to
              <br />
              follow
            </div>
          </div>
          <div className="flex gap-2.5 overflow-x-auto hide-scrollbar pb-2 flex-1">
            {filterTipsters(followTipsters).map((t) => (
              <TipsterCard
                key={t.id}
                tipster={t}
                isSubscribed={checkSubscribed(t.name)}
                onSubscribe={onSubscribe}
                onViewProfile={onViewProfile}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
