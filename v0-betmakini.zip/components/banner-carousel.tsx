"use client"

import { useState, useEffect, useCallback } from "react"
import { bannerImages } from "@/lib/data"

export default function BannerCarousel() {
  const [current, setCurrent] = useState(0)

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % bannerImages.length)
  }, [])

  useEffect(() => {
    const interval = setInterval(next, 4000)
    return () => clearInterval(interval)
  }, [next])

  return (
    <div className="mx-auto max-w-[480px] px-4 mb-[18px]">
      <div
        className="relative overflow-hidden rounded-[18px]"
        style={{ height: 200, background: "#111", boxShadow: "0 8px 24px rgba(0,0,0,0.4)" }}
      >
        {bannerImages.map((img, i) => (
          <div
            key={i}
            className="absolute inset-0 transition-opacity duration-800"
            style={{ opacity: i === current ? 1 : 0, zIndex: i === current ? 1 : 0 }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img || "/placeholder.svg"} alt={`Banner ${i + 1}`} className="w-full h-full object-cover" />
          </div>
        ))}
        <div className="absolute bottom-3.5 left-1/2 -translate-x-1/2 flex gap-2 z-[2]">
          {bannerImages.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className="cursor-pointer transition-all duration-300"
              style={{
                width: i === current ? 28 : 8,
                height: 8,
                borderRadius: i === current ? 5 : "50%",
                background: i === current ? "#5DCEA8" : "rgba(255,255,255,0.35)",
                border: "none",
              }}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
