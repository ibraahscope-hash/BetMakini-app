"use client"

import React from "react"

type Page = "home" | "betslips" | "subscription" | "account"

interface BottomNavProps {
  activePage: Page
  onNavigate: (page: Page) => void
}

const navItems: { page: Page; label: string; icon: React.ReactNode }[] = [
  {
    page: "home",
    label: "Home",
    icon: (
      <svg viewBox="0 0 24 24" width={26} height={26} fill="currentColor">
        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
      </svg>
    ),
  },
  {
    page: "betslips",
    label: "Betslips",
    icon: (
      <svg viewBox="0 0 24 24" width={26} height={26} fill="currentColor">
        <path d="M7 2v11h3v9l7-12h-4l4-8z" />
      </svg>
    ),
  },
  {
    page: "subscription",
    label: "Subscription",
    icon: (
      <svg viewBox="0 0 24 24" width={26} height={26} fill="currentColor">
        <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z" />
      </svg>
    ),
  },
  {
    page: "account",
    label: "Account",
    icon: (
      <svg viewBox="0 0 24 24" width={26} height={26} fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
      </svg>
    ),
  },
]

export default function BottomNav({ activePage, onNavigate }: BottomNavProps) {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 flex justify-around"
      style={{
        background: "linear-gradient(180deg, #0a0a0a, #000)",
        borderTop: "1px solid rgba(255,255,255,0.08)",
        padding: "12px 0 20px",
        zIndex: 9990,
      }}
    >
      {navItems.map((item) => (
        <button
          key={item.page}
          onClick={() => onNavigate(item.page)}
          className="flex flex-col items-center gap-[5px] cursor-pointer transition-all duration-300 border-none bg-transparent"
          style={{
            padding: "6px 12px",
            color: activePage === item.page ? "#5DCEA8" : "#888",
          }}
        >
          <div className="flex items-center justify-center" style={{ width: 28, height: 28 }}>
            {item.icon}
          </div>
          <span className="text-[11px] font-semibold">{item.label}</span>
        </button>
      ))}
    </nav>
  )
}
