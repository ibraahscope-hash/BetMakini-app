"use client"

interface HistoryPageProps {
  onClose: () => void
}

const historyData = [
  {
    date: "28 Nov 2024",
    games: [
      { league: "Premier League", match: "Man United vs Chelsea", bet: "Over 2.5 (1.75)", result: "won" as const },
      { league: "La Liga", match: "Real Madrid vs Barcelona", bet: "GG (1.80)", result: "won" as const },
    ],
  },
  {
    date: "27 Nov 2024",
    games: [
      { league: "Bundesliga", match: "Bayern vs Dortmund", bet: "Over 3.5 (2.10)", result: "lost" as const },
      { league: "Serie A", match: "Inter Milan vs AC Milan", bet: "1X (1.45)", result: "won" as const },
    ],
  },
]

export default function HistoryPage({ onClose }: HistoryPageProps) {
  return (
    <div className="fixed inset-0 overflow-y-auto" style={{ background: "#0a0a0a", zIndex: 9998, animation: "slideUp 0.3s ease" }}>
      <div className="mx-auto max-w-[480px] p-4" style={{ paddingBottom: 100 }}>
        <div className="flex items-center justify-between mb-6 pb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <h2 className="text-xl font-extrabold" style={{ color: "#5DCEA8" }}>
            Game History
          </h2>
          <button
            onClick={onClose}
            className="flex items-center justify-center rounded-full cursor-pointer text-lg font-bold border-none transition-all duration-300"
            style={{ width: 38, height: 38, background: "rgba(255,255,255,0.05)", color: "#5DCEA8" }}
          >
            &#10005;
          </button>
        </div>
        {historyData.map((group) => (
          <div key={group.date} className="mb-6">
            <div className="text-[13px] font-semibold mb-3" style={{ color: "#888" }}>
              {group.date}
            </div>
            {group.games.map((game) => (
              <div
                key={game.match}
                className="rounded-[14px] p-4 mb-3"
                style={{
                  background: "linear-gradient(180deg, rgba(255,255,255,0.03), rgba(0,0,0,0.15))",
                  borderLeft: `4px solid ${game.result === "won" ? "#00c853" : "#d50000"}`,
                }}
              >
                <div className="text-xs font-semibold mb-1" style={{ color: "#5DCEA8" }}>
                  {game.league}
                </div>
                <div className="text-base font-extrabold text-white mb-1">{game.match}</div>
                <div className="flex justify-between items-center">
                  <span className="text-[13px]" style={{ color: "#888" }}>
                    {game.bet}
                  </span>
                  <span
                    className="text-[11px] font-bold rounded-full"
                    style={{
                      padding: "4px 12px",
                      background: game.result === "won" ? "rgba(0,200,83,0.12)" : "rgba(200,50,50,0.12)",
                      color: game.result === "won" ? "#00c853" : "#ff6b6b",
                    }}
                  >
                    {game.result.toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
