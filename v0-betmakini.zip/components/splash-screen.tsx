"use client"

export default function SplashScreen() {
  return (
    <div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center"
      style={{ background: "linear-gradient(135deg, #000 0%, #0a1a0a 100%)" }}
    >
      <div
        className="flex items-center justify-center rounded-3xl mb-4"
        style={{
          width: 100,
          height: 100,
          background: "linear-gradient(135deg, rgba(93,206,168,0.15), rgba(0,100,0,0.2))",
          border: "3px solid rgba(93,206,168,0.3)",
          animation: "logoPulse 1s ease-in-out infinite",
        }}
      >
        <svg width={60} height={60} viewBox="0 0 24 24" fill="#5DCEA8">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
        </svg>
      </div>
      <h1
        className="text-[28px] font-black tracking-widest mb-2"
        style={{
          background: "linear-gradient(135deg, #5DCEA8, #fff)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
        }}
      >
        BetMakini
      </h1>
      <p className="text-sm" style={{ color: "rgba(93,206,168,0.8)" }}>
        Bet smart, Win big
      </p>
      <div className="mt-5 overflow-hidden rounded-sm" style={{ width: 120, height: 4, background: "rgba(255,255,255,0.1)" }}>
        <span className="block h-full" style={{ width: 0, background: "#5DCEA8", animation: "loadBar 1s ease-out forwards" }} />
      </div>
    </div>
  )
}
