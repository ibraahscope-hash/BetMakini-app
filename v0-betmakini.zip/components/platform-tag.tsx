"use client"

const platformLogos: Record<string, { src: string; bg: string }> = {
  sportybet: {
    src: "https://i.postimg.cc/s2gJyMsK/130ef232-729b-4d40-9946-c8435c34f8a2.jpg",
    bg: "#c8192e",
  },
  betway: {
    src: "https://i.postimg.cc/DzvxZCdq/c28c6c7c-b320-4e19-b1a3-b65f84ef858c.jpg",
    bg: "#000000",
  },
  betpawa: {
    src: "https://i.postimg.cc/GmrQ7Mfk/4aa870e5-593e-450a-a741-574b42111494.jpg",
    bg: "#f0f0f0",
  },
}

export default function PlatformTag({ platform }: { platform: string }) {
  const info = platformLogos[platform]

  if (!info) {
    return (
      <span
        className="inline-flex items-center justify-center text-[10px] font-bold"
        style={{
          width: 80,
          height: 28,
          borderRadius: 4,
          background: "#1a1a1a",
          color: "#aaa",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        {platform}
      </span>
    )
  }

  return (
    <div
      className="inline-flex items-center justify-center shrink-0"
      style={{
        width: 82,
        height: 28,
        borderRadius: 4,
        background: info.bg,
        overflow: "hidden",
      }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={info.src || "/placeholder.svg"}
        alt={platform}
        style={{
          maxWidth: "90%",
          maxHeight: "90%",
          objectFit: "contain",
        }}
      />
    </div>
  )
}
