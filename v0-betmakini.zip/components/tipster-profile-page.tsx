"use client"

import { type Tipster, allTipsters, freeTipster } from "@/lib/data"
import { useCountdown } from "@/hooks/use-countdown"
import VerifiedBadge from "./verified-badge"
import PlatformTag from "./platform-tag"
import AnimatedGoal from "./animated-goal"

interface TipsterProfilePageProps {
  tipsterId: string
  onBack: () => void
  onUnsubscribe: (name: string) => void
  onViewBetslips: (id: string) => void
}

export default function TipsterProfilePage({
  tipsterId,
  onBack,
  onUnsubscribe,
  onViewBetslips,
}: TipsterProfilePageProps) {
  const tipster =
    allTipsters.find((t) => t.id === tipsterId) ||
    (tipsterId === "freetips" ? freeTipster : null)
  if (!tipster) return null

  const lastResults = tipster.lastResults || Array(10).fill("won")

  const colorMap: Record<string, string> = {
    gold: "#b8860b",
    blue: "#1565c0",
    purple: "#6a1b9a",
    red: "#c62828",
    green: "#2e7d32",
  }
  const heroAccent = colorMap[tipster.color] || "#b8860b"

  return (
    <div
      className="fixed inset-0 overflow-y-auto"
      style={{
        background: "#0d0d0d",
        zIndex: 9998,
        animation: "slideUp 0.3s ease",
      }}
    >
      {/* Top Header Bar */}
      <div
        className="sticky top-0 flex items-center gap-3 px-4"
        style={{
          height: 56,
          background: "#0d0d0d",
          zIndex: 10,
          borderBottom: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <button
          onClick={onBack}
          className="flex items-center justify-center border-none cursor-pointer bg-transparent p-0"
          aria-label="Go back"
        >
          <svg
            width={24}
            height={24}
            viewBox="0 0 24 24"
            fill="none"
            stroke="#5DCEA8"
            strokeWidth={2.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </button>
        <span className="text-lg font-bold text-white tracking-tight">
          Tipster Profile
        </span>
      </div>

      {/* Hero Section */}
      <div
        className="relative flex flex-col items-center"
        style={{
          background: `linear-gradient(180deg, ${heroAccent} 0%, ${heroAccent}99 40%, #0d0d0d 100%)`,
          paddingBottom: 24,
        }}
      >
        {/* Back chevron on hero */}
        <button
          onClick={onBack}
          className="absolute left-4 top-4 flex items-center justify-center border-none cursor-pointer bg-transparent p-0"
          aria-label="Go back"
        >
          <svg
            width={28}
            height={28}
            viewBox="0 0 24 24"
            fill="none"
            stroke="#fff"
            strokeWidth={2.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </button>

        {/* Profile Image */}
        <div
          className="relative mt-2 overflow-hidden rounded-full"
          style={{
            width: 220,
            height: 220,
            border: "4px solid rgba(255,255,255,0.15)",
            boxShadow: "0 8px 40px rgba(0,0,0,0.5)",
          }}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={tipster.img || "/placeholder.svg"}
            alt={tipster.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Name + Verified */}
        <div className="flex items-center gap-2 mt-4">
          <span className="text-[26px] font-black text-white tracking-tight">
            {tipster.name}
          </span>
          <VerifiedBadge size={24} />
        </div>

        {/* Stats Row */}
        <div className="flex items-center justify-center gap-10 mt-5 w-full px-6">
          <div className="text-center">
            <div className="text-xl font-black text-white">{tipster.subscribers}</div>
            <div className="text-xs text-neutral-400">Subscribers</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-black text-white">{tipster.accuracy}%</div>
            <div className="text-xs text-neutral-400">Accuracy</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-black text-white">{tipster.betslips}</div>
            <div className="text-xs text-neutral-400">Betslips</div>
          </div>
        </div>

        {/* Unsubscribe Button */}
        <button
          onClick={() => onUnsubscribe(tipster.name)}
          className="mt-5 mx-6 w-[calc(100%-48px)] rounded-xl text-[15px] font-semibold cursor-pointer transition-all duration-200 border-none"
          style={{
            padding: "14px 0",
            background: "#2a2a2a",
            color: "#ccc",
          }}
        >
          Unsubscribe
        </button>
      </div>

      {/* Content Below Hero */}
      <div className="px-4 pt-5 pb-28">
        {/* Last 10 Betslips */}
        <div className="mb-6">
          <div className="text-sm font-bold text-neutral-300 mb-3">
            Last 10 Betslips
          </div>
          <div className="flex gap-2 flex-wrap">
            {lastResults.map((r: string, i: number) => {
              const isWon = r === "won"
              return (
                <div
                  key={i}
                  className="flex items-center justify-center rounded-full"
                  style={{
                    width: 34,
                    height: 34,
                    background: isWon
                      ? "rgba(0,200,83,0.15)"
                      : "rgba(255,255,255,0.08)",
                    border: isWon
                      ? "1.5px solid rgba(0,200,83,0.4)"
                      : "1.5px solid rgba(255,255,255,0.12)",
                  }}
                >
                  {isWon ? (
                    <svg
                      width={16}
                      height={16}
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#00c853"
                      strokeWidth={3}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M20 6L9 17l-5-5" />
                    </svg>
                  ) : (
                    <svg
                      width={14}
                      height={14}
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#888"
                      strokeWidth={3}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 6L6 18M6 6l12 12" />
                    </svg>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Betslip Info Card */}
        <ProfileBetslipCard tipster={tipster} onViewBetslips={onViewBetslips} />
      </div>
    </div>
  )
}

function ProfileBetslipCard({
  tipster,
  onViewBetslips,
}: {
  tipster: Tipster
  onViewBetslips: (id: string) => void
}) {
  const countdown = useCountdown(
    tipster.countdown.hours,
    tipster.countdown.mins,
    tipster.countdown.secs,
  )

  return (
    <div
      className="rounded-2xl p-5"
      style={{
        background: "#1a1a1a",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Top row: Odds + Active badge */}
      <div className="flex justify-between items-start">
        <div>
          <div className="text-[36px] font-black text-white leading-none">
            {tipster.odds.toFixed(2)}
          </div>
          <div className="text-xs text-neutral-500 mt-1">Odds</div>
        </div>
        <span
          className="inline-block rounded-md text-xs font-bold"
          style={{
            padding: "4px 14px",
            background: "rgba(0,200,83,0.12)",
            color: "#00c853",
            border: "1px solid rgba(0,200,83,0.25)",
          }}
        >
          {tipster.isFree ? "free" : "active"}
        </span>
      </div>

      {/* Validity + Price row */}
      <div className="flex justify-between items-end mt-3">
        <div className="text-xs text-neutral-500">
          {"Validity Time "}
          <span className="text-white font-semibold">
            {"• "}
            {countdown}
          </span>
        </div>
        <div className="text-lg font-black text-white">
          {tipster.isFree ? "BURE" : `Tzs ${tipster.price.toLocaleString()}/=`}
        </div>
      </div>

      {/* Platform Tags */}
      <div className="flex gap-1.5 flex-wrap mt-3">
        {tipster.platforms.map((p) => (
          <PlatformTag key={p} platform={p} />
        ))}
      </div>

      {/* View betslips button */}
      <button
        onClick={() => onViewBetslips(tipster.id)}
        className="w-full rounded-xl text-[15px] font-extrabold cursor-pointer mt-4 transition-all duration-200 border-none"
        style={{
          padding: "14px 0",
          background: "linear-gradient(135deg, #5DCEA8 0%, #3fb88e 50%, #5DCEA8 100%)",
          color: "#000",
        }}
      >
        View betslips <AnimatedGoal />
      </button>
    </div>
  )
}
