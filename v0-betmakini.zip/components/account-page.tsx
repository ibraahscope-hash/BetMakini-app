"use client"

import { useState, useEffect } from "react"
import { getCurrentUser, deleteUserAccount, isUnlocked, getRemainingTime, type UserAccount } from "@/lib/storage"
import { allTipsters } from "@/lib/data"

interface AccountPageProps {
  onShowPayment: () => void
  onLogout: () => void
}

type SubView = "main" | "mybetslips" | "paymenthistory"

export default function AccountPage({ onShowPayment, onLogout }: AccountPageProps) {
  const [user, setUser] = useState<UserAccount | null>(null)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [subView, setSubView] = useState<SubView>("main")

  useEffect(() => {
    setUser(getCurrentUser())
  }, [])

  const handleDelete = () => {
    deleteUserAccount()
    onLogout()
  }

  // Get truly unlocked (paid) tipsters only
  const unlockedTipsters = allTipsters.filter((t) => isUnlocked(t.id))
  const unlockedCount = unlockedTipsters.length

  // Sub-Header component
  const SubHeader = ({ title, onBack }: { title: string; onBack: () => void }) => (
    <div className="flex items-center gap-3 px-4" style={{ height: 56, borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
      <button
        onClick={onBack}
        className="flex items-center justify-center rounded-full cursor-pointer border-none p-0"
        style={{ width: 36, height: 36, background: "transparent" }}
      >
        <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
          <path d="M19 12H5M12 19l-7-7 7-7" />
        </svg>
      </button>
      <h2 className="text-lg font-extrabold text-white">{title}</h2>
    </div>
  )

  // Sub-view: My Betslips
  if (subView === "mybetslips") {
    return (
      <div className="min-h-screen" style={{ background: "#060606" }}>
        <div className="mx-auto max-w-[480px]">
          <SubHeader title="My Betslips" onBack={() => setSubView("main")} />
          <div className="px-4 pt-6 pb-8">
            {unlockedCount === 0 ? (
              <div className="flex flex-col items-center justify-center pt-16">
                <div
                  className="flex items-center justify-center rounded-full mb-6"
                  style={{
                    width: 96,
                    height: 96,
                    background: "radial-gradient(circle, rgba(93,206,168,0.08) 0%, transparent 70%)",
                    border: "2px dashed rgba(93,206,168,0.15)",
                  }}
                >
                  <svg width={40} height={40} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" opacity={0.3}>
                    <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
                  </svg>
                </div>
                <h3 className="text-lg font-extrabold text-white mb-2">Bado uja buy Betslips</h3>
                <p className="text-[13px] text-center leading-relaxed mb-8" style={{ color: "#555", maxWidth: 280 }}>
                  Huna betslips zozote kwa sasa. Nenda kwenye Betslips, chagua tipster unayempenda, lipia na upate booking codes.
                </p>
                <div
                  className="rounded-2xl w-full py-4 flex items-center justify-center gap-3"
                  style={{
                    background: "rgba(93,206,168,0.06)",
                    border: "1px solid rgba(93,206,168,0.1)",
                  }}
                >
                  <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" opacity={0.6}>
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                  <span className="text-sm font-bold" style={{ color: "#5DCEA8" }}>Tembelea Betslips kuanza</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {unlockedTipsters.map((t) => {
                  const remaining = getRemainingTime(t.id)
                  return (
                    <div
                      key={t.id}
                      className="rounded-2xl overflow-hidden"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.06)",
                      }}
                    >
                      <div className="flex items-center gap-3.5 px-4 py-3.5">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={t.img || "/placeholder.svg"}
                          alt={t.name}
                          className="rounded-full object-cover shrink-0"
                          style={{ width: 48, height: 48, border: "2px solid rgba(93,206,168,0.2)" }}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="text-[15px] font-bold text-white truncate">{t.name}</div>
                          <div className="text-[12px] mt-0.5" style={{ color: "#666" }}>
                            Odds: {t.odds.toFixed(2)}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span
                            className="inline-block rounded-md text-[11px] font-bold"
                            style={{
                              padding: "3px 10px",
                              background: "rgba(0,200,83,0.1)",
                              color: "#00c853",
                              border: "1px solid rgba(0,200,83,0.2)",
                            }}
                          >
                            active
                          </span>
                          {remaining && (
                            <div className="text-[11px] mt-1" style={{ color: "#666" }}>
                              {remaining.hours}h {remaining.mins}m left
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="mx-4" style={{ height: 1, background: "rgba(255,255,255,0.05)" }} />
                      <div className="flex items-center gap-2 px-4 py-2.5">
                        <span className="text-[12px]" style={{ color: "#555" }}>Platforms:</span>
                        <div className="flex gap-1.5">
                          {t.platforms.map((p) => (
                            <span key={p} className="text-[11px] font-semibold rounded-md" style={{ padding: "2px 6px", background: "rgba(255,255,255,0.05)", color: "#999" }}>
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  // Sub-view: Payment History
  if (subView === "paymenthistory") {
    return (
      <div className="min-h-screen" style={{ background: "#060606" }}>
        <div className="mx-auto max-w-[480px]">
          <SubHeader title="Payment History" onBack={() => setSubView("main")} />
          <div className="px-4 pt-6 pb-8">
            {unlockedCount === 0 ? (
              <div className="flex flex-col items-center justify-center pt-16">
                <div
                  className="flex items-center justify-center rounded-full mb-6"
                  style={{
                    width: 96,
                    height: 96,
                    background: "radial-gradient(circle, rgba(93,206,168,0.08) 0%, transparent 70%)",
                    border: "2px dashed rgba(93,206,168,0.15)",
                  }}
                >
                  <svg width={40} height={40} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" opacity={0.3}>
                    <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
                    <line x1="1" y1="10" x2="23" y2="10" />
                  </svg>
                </div>
                <h3 className="text-lg font-extrabold text-white mb-2">Hakuna malipo bado</h3>
                <p className="text-[13px] text-center leading-relaxed mb-8" style={{ color: "#555", maxWidth: 280 }}>
                  Bado hujafanya malipo yoyote. Unapolipia tipster, historia ya muamala wako itaonekana hapa.
                </p>
                <div
                  className="rounded-2xl w-full py-4 flex items-center justify-center gap-3"
                  style={{
                    background: "rgba(93,206,168,0.06)",
                    border: "1px solid rgba(93,206,168,0.1)",
                  }}
                >
                  <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" opacity={0.6}>
                    <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
                    <line x1="1" y1="10" x2="23" y2="10" />
                  </svg>
                  <span className="text-sm font-bold" style={{ color: "#5DCEA8" }}>Hakuna muamala wowote</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {unlockedTipsters.map((t) => (
                  <div
                    key={t.id}
                    className="rounded-2xl overflow-hidden"
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.06)",
                    }}
                  >
                    <div className="flex items-center gap-3.5 px-4 py-3.5">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={t.img || "/placeholder.svg"}
                        alt={t.name}
                        className="rounded-full object-cover shrink-0"
                        style={{ width: 48, height: 48, border: "2px solid rgba(93,206,168,0.2)" }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-[15px] font-bold text-white truncate">{t.name}</div>
                        <div className="text-[12px] mt-0.5" style={{ color: "#666" }}>
                          Leo, {new Date().toLocaleDateString("sw-TZ")}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-[16px] font-extrabold" style={{ color: "#5DCEA8" }}>
                          Tzs {t.price.toLocaleString()}/=
                        </div>
                      </div>
                    </div>
                    <div className="mx-4" style={{ height: 1, background: "rgba(255,255,255,0.05)" }} />
                    <div className="flex items-center justify-between px-4 py-2.5">
                      <span className="text-[12px]" style={{ color: "#555" }}>
                        Njia: Access Code
                      </span>
                      <span
                        className="rounded-md text-[11px] font-bold"
                        style={{
                          padding: "3px 10px",
                          background: "rgba(0,200,83,0.1)",
                          color: "#00c853",
                          border: "1px solid rgba(0,200,83,0.2)",
                        }}
                      >
                        Paid
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  // Main Account View
  return (
    <div className="min-h-screen" style={{ background: "#060606" }}>
      <div className="mx-auto max-w-[480px] px-5 pt-10 pb-4">
        {/* Avatar */}
        <div className="flex flex-col items-center mb-8">
          <div
            className="rounded-full overflow-hidden mb-4"
            style={{
              width: 100,
              height: 100,
              border: "3px solid rgba(255,255,255,0.12)",
              background: "#1a1a1a",
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={user?.avatar || "https://i.postimg.cc/Pq49NQzW/IMG-3575.png"}
              alt="User avatar"
              className="w-full h-full object-cover"
            />
          </div>
          <span className="text-lg font-bold text-white">{user?.username || "BetMakini User"}</span>
        </div>

        {/* Account Section */}
        <div className="mb-6">
          <span className="text-sm font-medium mb-3 block" style={{ color: "#888" }}>Account</span>
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
          >
            {/* My Betslips */}
            <button
              onClick={() => setSubView("mybetslips")}
              className="w-full flex items-center gap-4 px-5 cursor-pointer border-none"
              style={{ height: 60, background: "transparent" }}
            >
              <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
              </svg>
              <span className="flex-1 text-left text-[15px] font-semibold text-white">My Betslips</span>
              {unlockedCount > 0 && (
                <span
                  className="rounded-full text-[11px] font-bold"
                  style={{
                    padding: "2px 8px",
                    background: "rgba(93,206,168,0.12)",
                    color: "#5DCEA8",
                    minWidth: 22,
                    textAlign: "center",
                  }}
                >
                  {unlockedCount}
                </span>
              )}
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>

            <div className="mx-5" style={{ height: 1, background: "rgba(255,255,255,0.06)" }} />

            {/* Payment history */}
            <button
              onClick={() => setSubView("paymenthistory")}
              className="w-full flex items-center gap-4 px-5 cursor-pointer border-none"
              style={{ height: 60, background: "transparent" }}
            >
              <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
                <line x1="1" y1="10" x2="23" y2="10" />
              </svg>
              <span className="flex-1 text-left text-[15px] font-semibold text-white">Payment history</span>
              {unlockedCount > 0 && (
                <span
                  className="rounded-full text-[11px] font-bold"
                  style={{
                    padding: "2px 8px",
                    background: "rgba(93,206,168,0.12)",
                    color: "#5DCEA8",
                    minWidth: 22,
                    textAlign: "center",
                  }}
                >
                  {unlockedCount}
                </span>
              )}
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>

            <div className="mx-5" style={{ height: 1, background: "rgba(255,255,255,0.06)" }} />

            {/* Delete Account */}
            <button
              className="w-full flex items-center gap-4 px-5 cursor-pointer border-none"
              style={{ height: 60, background: "transparent" }}
              onClick={() => setShowDeleteConfirm(true)}
            >
              <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#888" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <polyline points="3 6 5 6 21 6" />
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
              </svg>
              <span className="flex-1 text-left text-[15px] font-semibold text-white">Delete Account</span>
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>

            <div className="mx-5" style={{ height: 1, background: "rgba(255,255,255,0.06)" }} />

            {/* Logout */}
            <button
              className="w-full flex items-center gap-4 px-5 cursor-pointer border-none"
              style={{ height: 60, background: "transparent" }}
              onClick={onLogout}
            >
              <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#888" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              <span className="flex-1 text-left text-[15px] font-semibold text-white">Logout</span>
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div
          className="fixed inset-0 flex items-center justify-center p-5"
          style={{ background: "rgba(0,0,0,0.85)", zIndex: 9999, backdropFilter: "blur(8px)" }}
        >
          <div
            className="text-center w-full"
            style={{
              maxWidth: 340,
              padding: 28,
              background: "#111",
              borderRadius: 22,
              border: "1px solid rgba(255,82,82,0.15)",
            }}
          >
            <div
              className="flex items-center justify-center rounded-full mx-auto mb-4"
              style={{ width: 56, height: 56, background: "rgba(255,82,82,0.12)" }}
            >
              <svg width={28} height={28} viewBox="0 0 24 24" fill="none" stroke="#ff5252" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <polyline points="3 6 5 6 21 6" />
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
              </svg>
            </div>
            <h3 className="text-lg font-extrabold text-white mb-2">Futa Account?</h3>
            <p className="text-[13px] mb-6 leading-relaxed" style={{ color: "#888" }}>
              Ukifuta account yako, data yako yote itapotea na huwezi kuirejesha.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 rounded-xl text-sm font-bold cursor-pointer border-none"
                style={{ padding: "12px 0", background: "#1a1a1a", color: "#fff" }}
              >
                Sitisha
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 rounded-xl text-sm font-bold cursor-pointer border-none"
                style={{ padding: "12px 0", background: "#ff5252", color: "#fff" }}
              >
                Futa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
