"use client"

import type { Tipster } from "@/lib/data"
import VerifiedBadge from "./verified-badge"

const colorGradients: Record<string, string> = {
  red: "linear-gradient(180deg, #8B2525 0%, #4a1515 50%, #2a0d0d 100%)",
  gold: "linear-gradient(180deg, #8B7525 0%, #4a4015 50%, #2a230d 100%)",
  green: "linear-gradient(180deg, #1a5a4a 0%, #0d3d32 50%, #061f1a 100%)",
  teal: "linear-gradient(180deg, #256a7a 0%, #154555 50%, #0a2a35 100%)",
  purple: "linear-gradient(180deg, #6a2580 0%, #451555 50%, #280d35 100%)",
  blue: "linear-gradient(180deg, #254a8B 0%, #152d55 50%, #0d1a35 100%)",
}

interface TipsterCardProps {
  tipster: Tipster
  isSubscribed: boolean
  onSubscribe: (name: string, img: string, id: string) => void
  onViewProfile: (id: string) => void
}

export default function TipsterCard({ tipster, isSubscribed, onSubscribe, onViewProfile }: TipsterCardProps) {
  return (
    <div
      className="shrink-0 flex flex-col relative overflow-hidden rounded-[14px]"
      style={{ width: 120, height: 175, background: colorGradients[tipster.color] || colorGradients.green }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={tipster.img || "/placeholder.svg"} alt={tipster.name} className="w-full object-cover object-top" style={{ height: 80 }} />
      <div
        className="flex-1 flex flex-col justify-between text-center"
        style={{ padding: "6px 6px 8px", background: "linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.6) 100%)" }}
      >
        <div className="flex items-center justify-center gap-[3px] mb-px">
          <span className="text-[10px] font-bold text-white truncate max-w-[70px]">{tipster.name}</span>
          <VerifiedBadge size={12} />
        </div>
        <div className="text-lg font-black text-white leading-none">{tipster.accuracy}%</div>
        <div className="text-[9px]" style={{ color: "rgba(255,255,255,0.6)" }}>
          Accuracy
        </div>
        {isSubscribed ? (
          <button
            onClick={() => onViewProfile(tipster.id)}
            className="w-full rounded-xl text-[9px] font-bold cursor-pointer transition-all duration-300 text-white"
            style={{ padding: "5px 6px", background: "rgba(255,255,255,0.15)", border: "1.5px solid rgba(255,255,255,0.5)" }}
          >
            View profile
          </button>
        ) : (
          <button
            onClick={() => onSubscribe(tipster.name, tipster.img, tipster.id)}
            className="w-full rounded-xl text-[9px] font-bold cursor-pointer transition-all duration-300"
            style={{ padding: "5px 6px", background: "linear-gradient(135deg, #5DCEA8, #3aa37a)", color: "#000", border: "none" }}
          >
            Subscribe
          </button>
        )}
      </div>
    </div>
  )
}
