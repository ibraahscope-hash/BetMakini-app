"use client"

import { useState, useRef, useEffect } from "react"
import { allTipsters, freeTipster } from "@/lib/data"
import { useCountdown } from "@/hooks/use-countdown"
import VerifiedBadge from "./verified-badge"
import PlatformTag from "./platform-tag"
import AnimatedGoal from "./animated-goal"

function FreeTipsterBanner() {
  const [copied, setCopied] = useState(false)
  const code = freeTipster.bookingCodes.sportybet

  const copyCode = () => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }).catch(() => alert("Code: " + code))
  }

  return (
    <div className="mx-auto max-w-[480px] px-4 mb-5">
      <div
        className="relative overflow-hidden rounded-[20px] p-[18px]"
        style={{ background: "linear-gradient(135deg, #0a3d2a 0%, #062018 100%)", border: "2px solid #5DCEA8" }}
      >
        <span
          className="absolute text-[11px] font-black"
          style={{
            top: 12,
            right: -30,
            background: "#5DCEA8",
            color: "#000",
            padding: "4px 40px",
            transform: "rotate(45deg)",
          }}
        >
          FREE
        </span>
        <div className="flex items-center gap-4 mb-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={freeTipster.img || "/placeholder.svg"}
            alt={freeTipster.name}
            className="rounded-full object-cover"
            style={{ width: 75, height: 75, border: "3px solid #5DCEA8", boxShadow: "0 4px 15px rgba(93,206,168,0.3)" }}
          />
          <div>
            <h3 className="text-xl font-extrabold text-white mb-1 flex items-center gap-2">
              {freeTipster.name} <VerifiedBadge size={20} />
            </h3>
            <p className="text-[13px] font-semibold" style={{ color: "#5DCEA8" }}>
              FREE SportyBet Code Daily!
            </p>
          </div>
        </div>
        <div className="flex gap-5 mb-4">
          <div className="text-center">
            <div className="text-[22px] font-black text-white">{freeTipster.accuracy}%</div>
            <div className="text-[11px]" style={{ color: "#888" }}>
              Accuracy
            </div>
          </div>
          <div className="text-center">
            <div className="text-[22px] font-black text-white">{freeTipster.odds}</div>
            <div className="text-[11px]" style={{ color: "#888" }}>
              Odds
            </div>
          </div>
          <div className="text-center">
            <div className="text-[22px] font-black text-white">{freeTipster.subscribers}</div>
            <div className="text-[11px]" style={{ color: "#888" }}>
              Subscribers
            </div>
          </div>
        </div>
        <div className="rounded-[14px] p-3.5 text-center" style={{ background: "rgba(0,0,0,0.4)" }}>
          <div className="flex items-center justify-center gap-2 mb-2">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="https://i.postimg.cc/7Zc5CjwP/IMG-3594.jpg"
              alt="SportyBet"
              className="rounded-md object-contain"
              style={{ width: 28, height: 28 }}
            />
            <span className="text-xs" style={{ color: "#888" }}>
              {"Today's"} <span className="font-bold" style={{ color: "#5DCEA8" }}>SportyBet</span> Code
            </span>
          </div>
          <div className="text-[28px] font-black tracking-wider mb-2.5" style={{ color: "#5DCEA8" }}>
            {code}
          </div>
          <button
            onClick={copyCode}
            className="w-full p-3 rounded-xl text-sm font-bold cursor-pointer transition-all duration-300 border-none"
            style={{ background: copied ? "#00c853" : "#5DCEA8", color: "#000" }}
          >
            {copied ? "Imecopy!" : "Copy Code - BURE!"}
          </button>
        </div>
      </div>
    </div>
  )
}

function BetslipCard({ tipster, onViewDetail }: { tipster: (typeof allTipsters)[0]; onViewDetail: (id: string) => void }) {
  const countdown = useCountdown(tipster.countdown.hours, tipster.countdown.mins, tipster.countdown.secs)

  const colorMap: Record<string, string> = {
    gold: "#b8860b",
    blue: "#1565c0",
    purple: "#6a1b9a",
    red: "#c62828",
    green: "#2e7d32",
  }
  const borderColor = colorMap[tipster.color] || "#b8860b"

  return (
    <div
      className="mx-4 mb-5 rounded-2xl overflow-hidden"
      style={{
        background: "#1a1a1a",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Tipster Header */}
      <div className="flex items-center gap-3.5 px-4 py-4">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={tipster.img || "/placeholder.svg"}
          alt={tipster.name}
          className="rounded-full object-cover shrink-0"
          style={{
            width: 64,
            height: 64,
            border: `3px solid ${borderColor}`,
            boxShadow: `0 4px 16px ${borderColor}33`,
          }}
        />
        <div>
          <h3 className="text-[17px] font-extrabold text-white flex items-center gap-2">
            {tipster.name} <VerifiedBadge size={16} />
          </h3>
          <p className="text-[13px] mt-0.5" style={{ color: "#888" }}>
            {'Subscribers \u2022'}
          </p>
        </div>
      </div>

      {/* Divider */}
      <div className="mx-4" style={{ height: 1, background: "rgba(255,255,255,0.08)" }} />

      {/* Betslip Info */}
      <div className="px-4 pt-4 pb-2">
        {/* Odds + Active badge */}
        <div className="flex justify-between items-start">
          <div>
            <div className="text-[36px] font-black text-white leading-none">{tipster.odds.toFixed(2)}</div>
            <div className="text-[13px] mt-1" style={{ color: "#888" }}>Odds</div>
          </div>
          <span
            className="rounded-md text-xs font-bold"
            style={{
              padding: "4px 14px",
              background: "rgba(0,200,83,0.12)",
              color: "#00c853",
              border: "1px solid rgba(0,200,83,0.25)",
            }}
          >
            active
          </span>
        </div>

        {/* Validity + Price */}
        <div className="flex justify-between items-end mt-3">
          <div className="text-[13px]" style={{ color: "#888" }}>
            {'Validity Time \u2022 '}
            <span className="text-white font-bold">{countdown}</span>
          </div>
          <div className="text-xl font-black text-white">
            Tzs {tipster.price.toLocaleString()}/=
          </div>
        </div>

        {/* Platform Tags */}
        <div className="flex gap-2 flex-wrap mt-3">
          {tipster.platforms.map((p) => (
            <PlatformTag key={p} platform={p} />
          ))}
        </div>
      </div>

      {/* View betslips button */}
      <div className="px-4 pt-3 pb-4">
        <button
          onClick={() => onViewDetail(tipster.id)}
          className="w-full rounded-[14px] text-[15px] font-extrabold cursor-pointer transition-all duration-300 border-none"
          style={{
            padding: "14px 0",
            background: "linear-gradient(135deg, #5DCEA8 0%, #3fb88e 50%, #5DCEA8 100%)",
            color: "#000",
          }}
        >
          View betslips <AnimatedGoal />
        </button>
      </div>
    </div>
  )
}

interface BetslipsPageProps {
  onViewDetail: (id: string) => void
  onShowHistory: () => void
  onShowStats: () => void
}

export default function BetslipsPage({ onViewDetail, onShowHistory, onShowStats }: BetslipsPageProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setLoading(true)
    const timer = setTimeout(() => setLoading(false), 1200)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false)
      }
    }
    document.addEventListener("click", handler)
    return () => document.removeEventListener("click", handler)
  }, [])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center" style={{ minHeight: "70vh" }}>
        <div className="relative" style={{ width: 56, height: 56 }}>
          <div
            className="absolute inset-0 rounded-full"
            style={{
              border: "3px solid rgba(93,206,168,0.15)",
            }}
          />
          <div
            className="absolute inset-0 rounded-full"
            style={{
              border: "3px solid transparent",
              borderTopColor: "#5DCEA8",
              animation: "spinRefresh 0.8s linear infinite",
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
              <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
            </svg>
          </div>
        </div>
        <p className="text-sm font-bold mt-4" style={{ color: "#5DCEA8" }}>Loading Betslips...</p>
        <p className="text-xs mt-1" style={{ color: "#555" }}>Fetching latest tips</p>
      </div>
    )
  }

  return (
    <div>
      <div className="mx-auto max-w-[480px] flex items-center justify-between relative px-4 pt-5 pb-4">
        <h2 className="text-2xl font-black text-white">Betslips</h2>
        <div className="relative" ref={menuRef}>
          <button
            onClick={(e) => {
              e.stopPropagation()
              setMenuOpen(!menuOpen)
            }}
            className="flex items-center justify-center cursor-pointer gap-[3px] transition-all duration-300 hover:scale-110"
            style={{
              width: 36,
              height: 36,
              background: "linear-gradient(135deg, #1a1a1a, #0a0a0a)",
              borderRadius: "50%",
              border: "2px solid rgba(93,206,168,0.2)",
            }}
          >
            <span className="block rounded-full" style={{ width: 5, height: 5, background: "#5DCEA8" }} />
            <span className="block rounded-full" style={{ width: 5, height: 5, background: "#5DCEA8" }} />
            <span className="block rounded-full" style={{ width: 5, height: 5, background: "#5DCEA8" }} />
          </button>
          {menuOpen && (
            <div
              className="absolute top-11 right-0 overflow-hidden"
              style={{
                background: "#111",
                border: "2px solid rgba(93,206,168,0.15)",
                borderRadius: 14,
                minWidth: 200,
                boxShadow: "0 10px 30px rgba(0,0,0,0.8)",
                animation: "slideDown 0.25s ease",
                zIndex: 100,
              }}
            >
              <button
                onClick={() => {
                  setMenuOpen(false)
                  onShowHistory()
                }}
                className="w-full flex items-center gap-3 text-sm font-semibold text-white cursor-pointer transition-all duration-200 hover:text-[#5DCEA8] border-none bg-transparent text-left"
                style={{ padding: "14px 16px", borderBottom: "1px solid rgba(255,255,255,0.05)" }}
              >
                <svg width={20} height={20} viewBox="0 0 24 24" fill="currentColor">
                  <path d="M13 3a9 9 0 00-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0013 21a9 9 0 000-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z" />
                </svg>
                History
              </button>
              <button
                onClick={() => {
                  setMenuOpen(false)
                  onShowStats()
                }}
                className="w-full flex items-center gap-3 text-sm font-semibold text-white cursor-pointer transition-all duration-200 hover:text-[#5DCEA8] border-none bg-transparent text-left"
                style={{ padding: "14px 16px" }}
              >
                <svg width={20} height={20} viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z" />
                </svg>
                Statistics
              </button>
            </div>
          )}
        </div>
      </div>

      <FreeTipsterBanner />

      <h3 className="text-base font-extrabold px-4 pb-4" style={{ color: "#c9a100" }}>
        Premium Tipsters
      </h3>

      {allTipsters.map((t) => (
        <BetslipCard key={t.id} tipster={t} onViewDetail={onViewDetail} />
      ))}
    </div>
  )
}
