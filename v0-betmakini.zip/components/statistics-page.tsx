"use client"

interface StatisticsPageProps {
  onClose: () => void
}

export default function StatisticsPage({ onClose }: StatisticsPageProps) {
  const stats = [
    { number: "156", label: "Total Tips" },
    { number: "75%", label: "Win Rate" },
    { number: "117", label: "Won" },
    { number: "39", label: "Lost" },
  ]

  return (
    <div className="fixed inset-0 overflow-y-auto" style={{ background: "#0a0a0a", zIndex: 9998, animation: "slideUp 0.3s ease" }}>
      <div className="mx-auto max-w-[480px] p-4" style={{ paddingBottom: 100 }}>
        <div className="flex items-center justify-between mb-6 pb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <h2 className="text-xl font-extrabold" style={{ color: "#5DCEA8" }}>
            Statistics
          </h2>
          <button
            onClick={onClose}
            className="flex items-center justify-center rounded-full cursor-pointer text-lg font-bold border-none transition-all duration-300"
            style={{ width: 38, height: 38, background: "rgba(255,255,255,0.05)", color: "#5DCEA8" }}
          >
            &#10005;
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3.5">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="rounded-2xl p-6 text-center"
              style={{ background: "linear-gradient(180deg, rgba(255,255,255,0.03), rgba(0,0,0,0.15))", border: "1px solid rgba(93,206,168,0.1)" }}
            >
              <div className="text-4xl font-black" style={{ color: "#5DCEA8" }}>
                {stat.number}
              </div>
              <div className="text-[13px] font-semibold mt-1.5" style={{ color: "#888" }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
