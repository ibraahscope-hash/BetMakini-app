"use client"

import { allTipsters } from "@/lib/data"
import { isUnlocked, getRemainingTime } from "@/lib/storage"
import { useCountdown } from "@/hooks/use-countdown"
import VerifiedBadge from "./verified-badge"
import PlatformTag from "./platform-tag"

interface BetslipDetailPageProps {
  tipsterId: string
  onBack: () => void
  onBuy: (tipsterId: string) => void
  unlockKey: number
}

export default function BetslipDetailPage({ tipsterId, onBack, onBuy, unlockKey }: BetslipDetailPageProps) {
  const tipster = allTipsters.find((t) => t.id === tipsterId)
  if (!tipster) return null

  return <BetslipDetailContent tipster={tipster} onBack={onBack} onBuy={onBuy} unlockKey={unlockKey} />
}

function BetslipDetailContent({
  tipster,
  onBack,
  onBuy,
  unlockKey,
}: {
  tipster: (typeof allTipsters)[0]
  onBack: () => void
  onBuy: (id: string) => void
  unlockKey: number
}) {
  const countdown = useCountdown(tipster.countdown.hours, tipster.countdown.mins, tipster.countdown.secs)
  const unlocked = isUnlocked(tipster.id)
  const remainingTime = getRemainingTime(tipster.id)

  // Force re-render when unlockKey changes
  void unlockKey

  return (
    <div
      className="fixed inset-0 overflow-y-auto"
      style={{ background: "#0a0a0a", zIndex: 9998, animation: "slideUp 0.3s ease", paddingBottom: 100 }}
    >
      <div className="flex items-center gap-3 p-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <button
          onClick={onBack}
          className="flex items-center justify-center cursor-pointer text-2xl font-bold border-none bg-transparent"
          style={{ width: 38, height: 38, borderRadius: "50%", color: "#5DCEA8" }}
        >
          &#8592;
        </button>
        <h2 className="text-xl font-extrabold text-white">Betslip Details</h2>
      </div>

      <div className="flex items-center gap-4 p-4">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={tipster.img || "/placeholder.svg"}
          alt={tipster.name}
          className="rounded-full object-cover"
          style={{ width: 60, height: 60, border: "2px solid rgba(255,255,255,0.1)" }}
        />
        <div>
          <div className="text-lg font-extrabold text-white flex items-center gap-2">
            {tipster.name} <VerifiedBadge size={16} />
          </div>
          <div className="text-[13px]" style={{ color: "#888" }}>
            Subscribers &bull; {tipster.subscribers}
          </div>
        </div>
      </div>

      <div className="px-4 pb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        <div className="text-4xl font-black text-white">{tipster.odds.toFixed(2)}</div>
        <div className="text-sm" style={{ color: "#888" }}>
          Odds
        </div>
      </div>

      <div
        className="flex justify-between items-center p-4"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}
      >
        <div className="text-sm" style={{ color: "#888" }}>
          Validity Time &bull; <span className="text-white font-bold">{countdown}</span>
        </div>
        <div className="text-xl font-black text-white">Tzs {tipster.price.toLocaleString()}/=</div>
      </div>

      {unlocked && remainingTime && (
        <div
          className="mx-4 rounded-xl p-3"
          style={{ background: "rgba(93,206,168,0.1)", border: "1px solid rgba(93,206,168,0.3)" }}
        >
          <div className="text-[13px] font-bold" style={{ color: "#5DCEA8" }}>
            Access yako itaisha baada ya: {remainingTime.hours}h {remainingTime.mins}m
          </div>
        </div>
      )}

      <div className="p-4">
        <div className="text-base font-extrabold text-white mb-3">Bet Companies</div>
        <div className="flex gap-2 flex-wrap">
          {tipster.platforms.map((p) => (
            <PlatformTag key={p} platform={p} />
          ))}
        </div>
      </div>

      <div
        className="mx-4 rounded-2xl overflow-hidden relative"
        style={{
          minHeight: 320,
          background: unlocked
            ? "rgba(0,0,0,0.3)"
            : "linear-gradient(160deg, #c8e6d8 0%, #d4ece0 25%, #e0efe8 50%, #d8ead4 75%, #b8dcc8 100%)",
        }}
      >
        {!unlocked && (
          <div
            className="absolute inset-0 flex items-center justify-center"
            style={{
              backdropFilter: "blur(12px)",
              WebkitBackdropFilter: "blur(12px)",
              background: "rgba(200,225,210,0.15)",
            }}
          >
            <button
              onClick={() => onBuy(tipster.id)}
              className="flex items-center gap-2.5 rounded-full text-sm font-bold cursor-pointer border-none"
              style={{
                padding: "14px 28px",
                background: "rgba(80,80,80,0.75)",
                color: "#fff",
                backdropFilter: "blur(8px)",
              }}
            >
              View betslip
              <svg width={20} height={20} viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z" />
              </svg>
            </button>
          </div>
        )}
        {unlocked && (
          <div className="p-5 h-full overflow-y-auto">
            {Object.entries(tipster.bookingCodes).map(([site, code]) => (
              <div
                key={site}
                className="rounded-xl p-3.5 mb-2.5"
                style={{ background: "rgba(93,206,168,0.12)", border: "1px solid rgba(93,206,168,0.25)" }}
              >
                <div className="text-xs mb-1" style={{ color: "#888" }}>
                  {site.charAt(0).toUpperCase() + site.slice(1)}
                </div>
                <div className="text-[22px] font-black tracking-wide" style={{ color: "#5DCEA8" }}>
                  {code}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <button
        onClick={() => onBuy(tipster.id)}
        disabled={unlocked}
        className="mx-4 mt-4 rounded-[14px] text-[17px] font-extrabold cursor-pointer transition-all duration-300 border-none"
        style={{
          padding: 18,
          width: "calc(100% - 32px)",
          background: unlocked ? "linear-gradient(180deg, #555, #333)" : "linear-gradient(180deg, #5DCEA8 0%, #3aa37a 100%)",
          color: unlocked ? "#888" : "#000",
        }}
      >
        {unlocked ? "Tayari Umefungua" : "Buy betslip"}
      </button>
    </div>
  )
}
