"use client"

import { allTipsters } from "@/lib/data"
import { getSubscribedTipsters } from "@/lib/storage"

interface SubscriptionPageProps {
  refreshKey: number
  onRefresh: () => void
  onViewProfile: (id: string) => void
}

export default function SubscriptionPage({ refreshKey, onRefresh, onViewProfile }: SubscriptionPageProps) {
  const subscribed = getSubscribedTipsters()
  void refreshKey
  void onRefresh

  return (
    <div>
      <div className="mx-auto max-w-[480px] px-4 pt-5 pb-5">
        <h2 className="text-2xl font-black text-white">Subscriptions</h2>
      </div>
      <div className="mx-auto max-w-[480px] px-4">
        {subscribed.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div
              className="flex items-center justify-center rounded-full mb-4"
              style={{ width: 64, height: 64, background: "rgba(93,206,168,0.08)" }}
            >
              <svg width={28} height={28} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
            <p className="text-sm text-neutral-500 text-center">
              Haujasubscribe tipster yeyote bado.
            </p>
          </div>
        ) : (
          <div className="flex flex-col">
            {subscribed.map((t, idx) => {
              const tipsterData = allTipsters.find((tip) => tip.id === t.tipsterId)
              const lastResults = tipsterData?.lastResults || []

              return (
                <div key={t.name}>
                  <button
                    onClick={() => onViewProfile(t.tipsterId)}
                    className="w-full flex items-center gap-3.5 py-4 px-1 bg-transparent border-none cursor-pointer text-left"
                  >
                    {/* Profile Photo */}
                    <div
                      className="shrink-0 rounded-full overflow-hidden"
                      style={{
                        width: 64,
                        height: 64,
                        border: `2.5px solid ${tipsterData?.color === "gold" ? "#C9A84C" : tipsterData?.color === "blue" ? "#4A90D9" : tipsterData?.color === "red" ? "#D94A4A" : tipsterData?.color === "purple" ? "#9B59B6" : "#5DCEA8"}`,
                      }}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={t.image || "/placeholder.svg"}
                        alt={t.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-[15px] font-bold text-white truncate">{t.name}</span>
                        <svg width={16} height={16} viewBox="0 0 24 24" fill="none">
                          <circle cx="12" cy="12" r="10" fill="#5DCEA8" />
                          <path d="M9 12l2 2 4-4" stroke="#000" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </div>
                      <div className="text-[11px] text-neutral-500 mb-2">Last 10 Slips</div>
                      <div className="flex items-center gap-1.5">
                        {lastResults.map((r, i) => (
                          <div
                            key={i}
                            className="flex items-center justify-center rounded-md"
                            style={{
                              width: 26,
                              height: 26,
                              background: r === "won" ? "rgba(93,206,168,0.15)" : "rgba(255,255,255,0.06)",
                              border: r === "won" ? "1px solid rgba(93,206,168,0.3)" : "1px solid rgba(255,255,255,0.08)",
                            }}
                          >
                            {r === "won" ? (
                              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#5DCEA8" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
                                <path d="M20 6L9 17l-5-5" />
                              </svg>
                            ) : (
                              <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
                                <path d="M18 6L6 18M6 6l12 12" />
                              </svg>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Right Chevron */}
                    <div className="shrink-0">
                      <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 18l6-6-6-6" />
                      </svg>
                    </div>
                  </button>

                  {/* Separator line */}
                  {idx < subscribed.length - 1 && (
                    <div style={{ height: 1, background: "linear-gradient(90deg, transparent, rgba(93,206,168,0.15), transparent)" }} />
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
