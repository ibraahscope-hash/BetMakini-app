"use client"

export default function VerifiedBadge({ size = 12 }: { size?: number }) {
  const iconSize = Math.round(size * 0.58)
  return (
    <span
      className="inline-flex items-center justify-center rounded-full shrink-0"
      style={{
        width: size,
        height: size,
        background: "linear-gradient(135deg, #1DA1F2, #0D8BD9)",
      }}
    >
      <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="#fff">
        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
      </svg>
    </span>
  )
}
