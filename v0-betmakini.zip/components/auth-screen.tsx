"use client"

import { useState } from "react"
import { registerUser, loginUser } from "@/lib/storage"

interface AuthScreenProps {
  onAuthenticated: () => void
}

export default function AuthScreen({ onAuthenticated }: AuthScreenProps) {
  const [mode, setMode] = useState<"login" | "signup">("login")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  const handleSubmit = () => {
    setError("")
    if (!username.trim()) { setError("Tafadhali ingiza username."); return }
    if (!password) { setError("Tafadhali ingiza password."); return }

    if (mode === "signup") {
      if (password !== confirmPassword) { setError("Password hazilingani."); return }
      setLoading(true)
      setTimeout(() => {
        const result = registerUser(username, password)
        setLoading(false)
        if (result.success) { onAuthenticated() } else { setError(result.error || "Kuna tatizo.") }
      }, 800)
    } else {
      setLoading(true)
      setTimeout(() => {
        const result = loginUser(username, password)
        setLoading(false)
        if (result.success) { onAuthenticated() } else { setError(result.error || "Kuna tatizo.") }
      }, 800)
    }
  }

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center px-6"
      style={{ background: "linear-gradient(180deg, #0a1a10 0%, #060606 40%, #060606 100%)" }}
    >
      {/* Logo */}
      <div className="mb-8 flex flex-col items-center">
        <div
          className="rounded-full overflow-hidden mb-4"
          style={{
            width: 80,
            height: 80,
            boxShadow: "0 8px 32px rgba(93,206,168,0.25)",
            border: "3px solid rgba(93,206,168,0.3)",
          }}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://i.postimg.cc/0NfzyjWB/772dee17-0080-4c27-a0c5-f07bda590291.jpg"
            alt="BetMakini"
            className="w-full h-full object-cover"
          />
        </div>
        <h1 className="text-2xl font-black text-white tracking-tight">BetMakini</h1>
        <p className="text-sm font-semibold mt-1" style={{ color: "#5DCEA8" }}>Bet smart, Win big</p>
      </div>

      {/* Card */}
      <div
        className="w-full max-w-[380px] rounded-3xl"
        style={{
          padding: "32px 24px",
          background: "#0f0f0f",
          border: "1px solid rgba(255,255,255,0.06)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.5)",
        }}
      >
        {/* Tab Switch */}
        <div
          className="flex rounded-xl mb-7 overflow-hidden"
          style={{ background: "#1a1a1a", padding: 3 }}
        >
          <button
            onClick={() => { setMode("login"); setError("") }}
            className="flex-1 py-2.5 rounded-lg text-sm font-bold border-none cursor-pointer transition-all duration-300"
            style={{
              background: mode === "login" ? "#5DCEA8" : "transparent",
              color: mode === "login" ? "#000" : "#666",
            }}
          >
            Ingia
          </button>
          <button
            onClick={() => { setMode("signup"); setError("") }}
            className="flex-1 py-2.5 rounded-lg text-sm font-bold border-none cursor-pointer transition-all duration-300"
            style={{
              background: mode === "signup" ? "#5DCEA8" : "transparent",
              color: mode === "signup" ? "#000" : "#666",
            }}
          >
            Jisajili
          </button>
        </div>

        <h2 className="text-xl font-extrabold text-white mb-1.5">
          {mode === "login" ? "Karibu Tena!" : "Tengeneza Account"}
        </h2>
        <p className="text-[13px] mb-6" style={{ color: "#666" }}>
          {mode === "login" ? "Ingiza taarifa zako kuendelea." : "Jisajili kupata tips bora za betting."}
        </p>

        {/* Username */}
        <div className="mb-4">
          <label className="block text-xs font-semibold mb-2" style={{ color: "#888" }}>Username</label>
          <div
            className="flex items-center rounded-xl overflow-hidden"
            style={{
              background: "#161616",
              border: `1px solid ${error && !username.trim() ? "#ff5252" : "rgba(255,255,255,0.08)"}`,
              transition: "border-color 0.2s",
            }}
          >
            <div className="flex items-center justify-center" style={{ width: 48, flexShrink: 0 }}>
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            </div>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Ingiza username yako"
              className="flex-1 bg-transparent border-none outline-none text-sm text-white py-3.5 pr-4"
              style={{ fontSize: 14, fontWeight: 500 }}
              autoComplete="username"
            />
          </div>
        </div>

        {/* Password */}
        <div className="mb-4">
          <label className="block text-xs font-semibold mb-2" style={{ color: "#888" }}>Password</label>
          <div
            className="flex items-center rounded-xl overflow-hidden"
            style={{
              background: "#161616",
              border: `1px solid ${error && !password ? "#ff5252" : "rgba(255,255,255,0.08)"}`,
              transition: "border-color 0.2s",
            }}
          >
            <div className="flex items-center justify-center" style={{ width: 48, flexShrink: 0 }}>
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
            </div>
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Ingiza password"
              className="flex-1 bg-transparent border-none outline-none text-sm text-white py-3.5"
              style={{ fontSize: 14, fontWeight: 500 }}
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
            />
            <button
              onClick={() => setShowPassword(!showPassword)}
              className="flex items-center justify-center border-none cursor-pointer bg-transparent"
              style={{ width: 44, flexShrink: 0 }}
              type="button"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                {showPassword ? (
                  <>
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                    <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                    <line x1="1" y1="1" x2="23" y2="23" />
                  </>
                ) : (
                  <>
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </>
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Confirm Password (sign up only) */}
        {mode === "signup" && (
          <div className="mb-4">
            <label className="block text-xs font-semibold mb-2" style={{ color: "#888" }}>Thibitisha Password</label>
            <div
              className="flex items-center rounded-xl overflow-hidden"
              style={{
                background: "#161616",
                border: `1px solid ${error && password !== confirmPassword ? "#ff5252" : "rgba(255,255,255,0.08)"}`,
                transition: "border-color 0.2s",
              }}
            >
              <div className="flex items-center justify-center" style={{ width: 48, flexShrink: 0 }}>
                <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                </svg>
              </div>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Ingiza password tena"
                className="flex-1 bg-transparent border-none outline-none text-sm text-white py-3.5 pr-4"
                style={{ fontSize: 14, fontWeight: 500 }}
                autoComplete="new-password"
              />
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div
            className="rounded-xl text-[13px] font-semibold mb-4 flex items-center gap-2"
            style={{ padding: "10px 14px", background: "rgba(255,82,82,0.1)", color: "#ff5252", border: "1px solid rgba(255,82,82,0.15)" }}
          >
            <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#ff5252" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="15" y1="9" x2="9" y2="15" />
              <line x1="9" y1="9" x2="15" y2="15" />
            </svg>
            {error}
          </div>
        )}

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={loading}
          className="w-full rounded-xl text-[15px] font-extrabold cursor-pointer border-none transition-all duration-300 flex items-center justify-center gap-2"
          style={{
            padding: "15px 0",
            background: loading ? "rgba(93,206,168,0.5)" : "linear-gradient(135deg, #5DCEA8 0%, #3fb88e 50%, #5DCEA8 100%)",
            color: "#000",
            boxShadow: loading ? "none" : "0 4px 20px rgba(93,206,168,0.25)",
          }}
        >
          {loading ? (
            <div
              className="rounded-full"
              style={{
                width: 20,
                height: 20,
                border: "2.5px solid rgba(0,0,0,0.2)",
                borderTopColor: "#000",
                animation: "spinRefresh 0.6s linear infinite",
              }}
            />
          ) : (
            mode === "login" ? "Ingia Sasa" : "Jisajili Sasa"
          )}
        </button>

        {/* Switch mode */}
        <p className="text-center text-[13px] mt-5" style={{ color: "#666" }}>
          {mode === "login" ? "Huna account? " : "Una account tayari? "}
          <button
            onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError("") }}
            className="bg-transparent border-none cursor-pointer font-bold"
            style={{ color: "#5DCEA8" }}
          >
            {mode === "login" ? "Jisajili" : "Ingia"}
          </button>
        </p>
      </div>

      {/* Footer */}
      <p className="text-[11px] mt-6" style={{ color: "#333" }}>
        BetMakini v1.0
      </p>
    </div>
  )
}
