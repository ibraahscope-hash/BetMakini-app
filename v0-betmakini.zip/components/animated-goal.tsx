"use client"

export default function AnimatedGoal() {
  return (
    <span className="inline-flex items-center relative" style={{ width: 38, height: 22 }}>
      <span
        className="absolute"
        style={{
          fontSize: 16,
          left: 0,
          top: 2,
          animation: "kickBall 1.8s ease-in-out infinite",
        }}
      >
        {"\u26BD"}
      </span>
      <span
        style={{
          fontSize: 16,
          position: "absolute",
          right: 0,
          top: 2,
        }}
      >
        {"\uD83E\uDD45"}
      </span>

      <style jsx>{`
        @keyframes kickBall {
          0% {
            transform: translateX(0px) scale(1);
            opacity: 1;
          }
          15% {
            transform: translateX(2px) translateY(-6px) scale(1.15);
            opacity: 1;
          }
          40% {
            transform: translateX(12px) translateY(-3px) scale(1.05);
            opacity: 1;
          }
          60% {
            transform: translateX(18px) translateY(0px) scale(0.95);
            opacity: 1;
          }
          75% {
            transform: translateX(20px) translateY(0px) scale(0.85);
            opacity: 0.7;
          }
          85% {
            transform: translateX(20px) translateY(0px) scale(0.7);
            opacity: 0;
          }
          86% {
            transform: translateX(0px) scale(0);
            opacity: 0;
          }
          100% {
            transform: translateX(0px) scale(1);
            opacity: 1;
          }
        }
      `}</style>
    </span>
  )
}
