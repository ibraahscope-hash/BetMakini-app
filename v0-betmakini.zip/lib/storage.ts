const STORAGE_USED_CODES = "betmakini_used_codes"
const STORAGE_UNLOCK = "betmakini_booking_unlock"
const STORAGE_SUBSCRIBED = "betmakini_subscribed_tipsters"
const STORAGE_USERS = "betmakini_users"
const STORAGE_CURRENT_USER = "betmakini_current_user"

export interface UserAccount {
  username: string
  password: string
  createdAt: string
  avatar: string
}

function getUsers(): UserAccount[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_USERS) || "[]") || []
  } catch {
    return []
  }
}

function saveUsers(users: UserAccount[]) {
  localStorage.setItem(STORAGE_USERS, JSON.stringify(users))
}

export function registerUser(username: string, password: string): { success: boolean; error?: string } {
  const users = getUsers()
  const normalizedName = username.trim().toLowerCase()
  if (normalizedName.length < 3) return { success: false, error: "Username lazima iwe na herufi 3 au zaidi." }
  if (password.length < 4) return { success: false, error: "Password lazima iwe na herufi 4 au zaidi." }
  if (users.find((u) => u.username.toLowerCase() === normalizedName)) {
    return { success: false, error: "Username hii imeshatumika. Chagua nyingine." }
  }
  const newUser: UserAccount = {
    username: username.trim(),
    password,
    createdAt: new Date().toISOString(),
    avatar: "https://i.postimg.cc/Pq49NQzW/IMG-3575.png",
  }
  users.push(newUser)
  saveUsers(users)
  localStorage.setItem(STORAGE_CURRENT_USER, JSON.stringify(newUser))
  return { success: true }
}

export function loginUser(username: string, password: string): { success: boolean; error?: string } {
  const users = getUsers()
  const user = users.find((u) => u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password)
  if (!user) return { success: false, error: "Username au password si sahihi." }
  localStorage.setItem(STORAGE_CURRENT_USER, JSON.stringify(user))
  return { success: true }
}

export function getCurrentUser(): UserAccount | null {
  try {
    const raw = localStorage.getItem(STORAGE_CURRENT_USER)
    if (!raw) return null
    return JSON.parse(raw)
  } catch {
    return null
  }
}

export function logoutUser() {
  localStorage.removeItem(STORAGE_CURRENT_USER)
}

export function deleteUserAccount() {
  const current = getCurrentUser()
  if (!current) return
  const users = getUsers().filter((u) => u.username.toLowerCase() !== current.username.toLowerCase())
  saveUsers(users)
  localStorage.removeItem(STORAGE_CURRENT_USER)
  localStorage.removeItem(STORAGE_SUBSCRIBED)
}
const HOURS_8_MS = 8 * 60 * 60 * 1000

interface UsedCode {
  tipsterId: string
  usedAt: number
  locked: boolean
}

interface SubscribedTipster {
  name: string
  date: string
  image: string
  tipsterId: string
}

export function getUsedCodes(): Record<string, UsedCode> {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_USED_CODES) || "{}") || {}
  } catch {
    return {}
  }
}

export function saveUsedCode(code: string, tipsterId: string) {
  const usedCodes = getUsedCodes()
  usedCodes[code] = { tipsterId, usedAt: Date.now(), locked: true }
  localStorage.setItem(STORAGE_USED_CODES, JSON.stringify(usedCodes))
}

export function isCodeValid(code: string, accessCodes: string[]): boolean {
  const upperCode = code.toUpperCase().replace(/\s/g, "")
  if (!accessCodes.includes(upperCode)) return false
  const usedCodes = getUsedCodes()
  if (usedCodes[upperCode]?.locked) return false
  return true
}

export function saveUnlock(tipsterId: string) {
  const key = `${STORAGE_UNLOCK}_${tipsterId}`
  localStorage.setItem(key, JSON.stringify({ unlockedAt: Date.now(), expiresAt: Date.now() + HOURS_8_MS }))
}

export function isUnlocked(tipsterId: string): boolean {
  const key = `${STORAGE_UNLOCK}_${tipsterId}`
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return false
    const obj = JSON.parse(raw)
    if (Date.now() > obj.expiresAt) {
      localStorage.removeItem(key)
      return false
    }
    return true
  } catch {
    return false
  }
}

export function getRemainingTime(tipsterId: string): { hours: number; mins: number; total: number } | null {
  const key = `${STORAGE_UNLOCK}_${tipsterId}`
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return null
    const obj = JSON.parse(raw)
    const remaining = obj.expiresAt - Date.now()
    if (remaining <= 0) return null
    const hours = Math.floor(remaining / (60 * 60 * 1000))
    const mins = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000))
    return { hours, mins, total: remaining }
  } catch {
    return null
  }
}

export function getSubscribedTipsters(): SubscribedTipster[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_SUBSCRIBED) || "[]") || []
  } catch {
    return []
  }
}

export function addSubscribedTipster(name: string, img: string, tipsterId: string): SubscribedTipster[] {
  const tipsters = getSubscribedTipsters()
  if (!tipsters.find((t) => t.name === name)) {
    tipsters.push({ name, date: new Date().toLocaleDateString("sw-TZ"), image: img, tipsterId })
    localStorage.setItem(STORAGE_SUBSCRIBED, JSON.stringify(tipsters))
  }
  return tipsters
}

export function removeSubscribedTipster(name: string) {
  let tipsters = getSubscribedTipsters()
  tipsters = tipsters.filter((t) => t.name !== name)
  localStorage.setItem(STORAGE_SUBSCRIBED, JSON.stringify(tipsters))
}

export function isSubscribed(name: string): boolean {
  return getSubscribedTipsters().some((t) => t.name === name)
}
