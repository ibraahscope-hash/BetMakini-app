export interface Tipster {
  id: string
  name: string
  accuracy: number
  img: string
  color: string
  odds: number
  subscribers: string
  betslips: number
  price: number
  platforms: string[]
  bookingCodes: Record<string, string>
  isFree?: boolean
  lastResults: string[]
  countdown: { hours: number; mins: number; secs: number }
}

export const topTipsterPhotos = [
  "https://files.catbox.moe/6lkb8g.jpg",
  "https://files.catbox.moe/03upf1.jpg",
  "https://files.catbox.moe/w93rqf.jpg",
  "https://files.catbox.moe/uheso3.jpg",
  "https://files.catbox.moe/yw86sd.jpg",
]

export const followTipsterPhotos = [
  "https://files.catbox.moe/6lkb8g.jpg",
  "https://files.catbox.moe/03upf1.jpg",
  "https://files.catbox.moe/w93rqf.jpg",
  "https://files.catbox.moe/uheso3.jpg",
  "https://files.catbox.moe/yw86sd.jpg",
]

export const bannerImages = [
  "https://files.catbox.moe/a3caoh.png",
  "https://files.catbox.moe/6giq00.png",
  "https://files.catbox.moe/s0es9c.png",
  "https://files.catbox.moe/gte5cj.png",
  "https://files.catbox.moe/ag3s1f.png",
  "https://files.catbox.moe/tktrlp.png",
]

export const gameHistoryScreenshots: Record<string, string> = {
  rockstar: "https://files.catbox.moe/oodtj8.png",
  unstoppable: "https://files.catbox.moe/oodtj8.png",
  deboss: "https://files.catbox.moe/oodtj8.png",
  jobless: "https://files.catbox.moe/oodtj8.png",
  calvintips: "https://files.catbox.moe/oodtj8.png",
  profitnation: "https://files.catbox.moe/oodtj8.png",
}

export const freeTipster: Tipster = {
  id: "freetips",
  name: "FreeTips Daily",
  accuracy: 72.5,
  img: "https://i.postimg.cc/xjGMWp5M/IMG-3472.jpg",
  color: "green",
  odds: 2.15,
  subscribers: "15.2k",
  betslips: 89,
  price: 0,
  platforms: ["sportybet"],
  bookingCodes: { sportybet: "FREE7823" },
  isFree: true,
  lastResults: ["won", "won", "won", "lost", "won", "won", "won", "won", "lost", "won"],
  countdown: { hours: 6, mins: 45, secs: 30 },
}

export const allTipsters: Tipster[] = [
  {
    id: "rockstar",
    name: "Rockstar",
    accuracy: 67.4,
    img: "https://i.postimg.cc/xjGMWp5M/IMG-3472.jpg",
    color: "gold",
    odds: 2.35,
    subscribers: "41.5k",
    betslips: 292,
    price: 2000,
    platforms: ["sportybet", "betway", "betpawa"],
    bookingCodes: { sportybet: "RS45789", betway: "RS98765", betpawa: "RS12345" },
    lastResults: ["lost", "lost", "won", "won", "won", "won", "won", "won", "won", "lost"],
    countdown: { hours: 7, mins: 23, secs: 45 },
  },
  {
    id: "unstoppable",
    name: "Unstoppable",
    accuracy: 66.7,
    img: "https://i.postimg.cc/hGh0n8j5/34c58f04-e339-4f8b-bb64-3f830cecc543.jpg",
    color: "blue",
    odds: 2.15,
    subscribers: "38.2k",
    betslips: 256,
    price: 2500,
    platforms: ["sportybet", "betway", "betpawa"],
    bookingCodes: { sportybet: "UN11223", betway: "UN77889", betpawa: "UN33445" },
    lastResults: ["won", "won", "lost", "won", "won", "won", "lost", "won", "won", "won"],
    countdown: { hours: 5, mins: 12, secs: 18 },
  },
  {
    id: "deboss",
    name: "De-Boss",
    accuracy: 64.5,
    img: "https://i.postimg.cc/mhxYNKNq/90d6f4ef-9a3b-477e-963f-cd3d00a27e95.jpg",
    color: "red",
    odds: 1.92,
    subscribers: "51.3k",
    betslips: 312,
    price: 5000,
    platforms: ["sportybet", "betway", "betpawa"],
    bookingCodes: { sportybet: "DB99001", betway: "DB33445", betpawa: "DB77788" },
    lastResults: ["won", "won", "won", "won", "won", "won", "lost", "won", "won", "won"],
    countdown: { hours: 8, mins: 15, secs: 27 },
  },
  {
    id: "jobless",
    name: "Jobless",
    accuracy: 64.0,
    img: "https://i.postimg.cc/hGC3bPzj/7a86b0b5-190c-4ef8-9bcd-9f2bccd5d19f.jpg",
    color: "purple",
    odds: 2.45,
    subscribers: "33.8k",
    betslips: 224,
    price: 3500,
    platforms: ["sportybet", "betway", "betpawa"],
    bookingCodes: { sportybet: "JB88990", betway: "JB44556", betpawa: "JB22334" },
    lastResults: ["won", "won", "won", "lost", "won", "won", "won", "won", "lost", "won"],
    countdown: { hours: 6, mins: 42, secs: 11 },
  },
  {
    id: "calvintips",
    name: "Calvin Tips",
    accuracy: 69.2,
    img: "https://i.postimg.cc/FsHBnSvb/IMG-3585.jpg",
    color: "gold",
    odds: 2.55,
    subscribers: "28.7k",
    betslips: 198,
    price: 3000,
    platforms: ["sportybet", "betway", "betpawa"],
    bookingCodes: { sportybet: "CT34521", betway: "CT55432", betpawa: "CT87654" },
    lastResults: ["won", "won", "won", "won", "lost", "won", "won", "won", "won", "lost"],
    countdown: { hours: 5, mins: 38, secs: 22 },
  },
  {
    id: "profitnation",
    name: "Profit Nation",
    accuracy: 65.8,
    img: "https://i.postimg.cc/W3X1TZHz/IMG-3532.jpg",
    color: "blue",
    odds: 2.08,
    subscribers: "22.4k",
    betslips: 176,
    price: 2500,
    platforms: ["sportybet", "betway", "betpawa"],
    bookingCodes: { sportybet: "PN44567", betway: "PN77834", betpawa: "PN99012" },
    lastResults: ["won", "lost", "won", "won", "won", "won", "won", "lost", "won", "won"],
    countdown: { hours: 7, mins: 10, secs: 55 },
  },
]

export const topTipsters = allTipsters.slice(0, 3)
export const followTipsters = allTipsters.slice(3, 6)

export const accessCodes = [
  "B3THK5I9", "X9LMP2RT", "V7SKW8ZQ", "J2NPHD3X", "M5QZTB7W",
  "R8YXCG1L", "F0VDZP6S", "K3NTLW9B", "H1SZXJ4M", "Q6WMRD2V",
  "L9PKTF5Y", "G4NBHV7C", "Z0XWJS8Q", "D3VQKR1F", "S7MYCL6T",
  "C2JFBP9Z", "A8RHTW0G", "E5XZNV3L", "U1DYFM7K", "I6QSHB2M",
  "Y9VTPG4W", "N0LKJX8S", "T3MZCD5Q", "O7RWFN2V", "P4GHYS9Z",
  "B8JXKL1T", "M2VCND7R", "F6SYQW0X", "K1HZRP3L", "H5TGDM9C",
  "Q8WXNZ4V", "L3PFKY6B", "G0RBJS7M", "Z2XVCL1F", "D9MQHT5S",
  "S4JYBN8Q", "C7VAZR0L", "A1RXWP3K", "E6TYND2M", "U5FSGQ9V",
  "I8PSLC4W", "Y3MTXZ7S", "N9LKDH0Q", "T1RVFW6Z", "O2GYJS5B",
  "P7HXKN8M", "B0VLCT3F", "M4SYNP9R", "F1QWZJ6L", "K5HRDB2C",
  "H9TWMX7V", "Q6YPNZ0S", "L8KGJR4Q", "G3RBVS1M", "Z5XCLT9F",
  "D2MQHW8B", "S0JYFP7Z", "C4VANZ3K", "A7RXGS6L", "E1TYQB5M",
  "U9FSLP0V", "I3PSHW2W", "Y5MTJZ8S", "N6LKDY4Q", "T0RVFG7Z",
  "O8GYKN1B", "P3HXVC9M", "B2SYLR5F", "M7QWJB0R", "F9HRDT6C",
  "K4TWMZ3V", "H1YPNX8S", "Q5KGJS0Q", "L3RBVF6M", "G9XCLT2F",
  "Z1MQHW7B", "D4JYFP5Z", "S8VANZ3K", "C6RXGS1L", "A0TYQB9M",
  "E7FSLP8V", "U3PSHW3W", "I4MTJZ7S", "Y7LKDY9Q", "N5RVFG1Z",
  "T9GYKN5B", "O1HXVC2M", "P5SYLR0F", "B4QWJB6R", "M6HRDT4C",
  "F8TWMZ8V", "K3YPNX9S", "H6KGJS0Q", "Q2RBVF7M", "L0XCLT9F",
  "G7MQHW1B", "Z5JYFP4Z", "D9VANZ0K", "S3RXGS5L", "C8TYQB6M",
]

export function getPlatformName(id: string): string {
  const names: Record<string, string> = {
    sportybet: "SportyBet",
    paripesa: "PARIPESA",
    betpawa: "betPawa",
    betway: "betway",
    betika: "Betika",
    mbet: "M-bet",
    wasafibet: "Wasafi",
    "1xbet": "1xBet",
    bet365: "Bet365",
    sportypesa: "Sportypesa",
    parimatch: "Parimatch",
  }
  return names[id] || id
}
