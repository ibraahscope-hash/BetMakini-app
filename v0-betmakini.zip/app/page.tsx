"use client"

import { useState, useEffect, useCallback } from "react"
import { addSubscribedTipster, removeSubscribedTipster, getCurrentUser, logoutUser } from "@/lib/storage"
import SplashScreen from "@/components/splash-screen"
import AuthScreen from "@/components/auth-screen"
import BottomNav from "@/components/bottom-nav"
import HomePage from "@/components/home-page"
import BetslipsPage from "@/components/betslips-page"
import BetslipDetailPage from "@/components/betslip-detail-page"
import TipsterProfilePage from "@/components/tipster-profile-page"
import SubscriptionPage from "@/components/subscription-page"
import AccountPage from "@/components/account-page"
import PaymentPage from "@/components/payment-page"
import HistoryPage from "@/components/history-page"
import StatisticsPage from "@/components/statistics-page"

type Page = "home" | "betslips" | "subscription" | "account"

export default function BetMakiniApp() {
  const [showSplash, setShowSplash] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authChecked, setAuthChecked] = useState(false)
  const [activePage, setActivePage] = useState<Page>("home")
  const [refreshKey, setRefreshKey] = useState(0)

  // Overlay states
  const [showDetail, setShowDetail] = useState<string | null>(null)
  const [showProfile, setShowProfile] = useState<string | null>(null)
  const [showPayment, setShowPayment] = useState<string | null>(null)
  const [showPaymentGeneral, setShowPaymentGeneral] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [showStats, setShowStats] = useState(false)
  const [showSubscribeModal, setShowSubscribeModal] = useState<string | null>(null)
  const [unlockKey, setUnlockKey] = useState(0)

  useEffect(() => {
    // Check if user is already logged in
    const user = getCurrentUser()
    setIsAuthenticated(!!user)
    setAuthChecked(true)
    const timer = setTimeout(() => setShowSplash(false), 1200)
    return () => clearTimeout(timer)
  }, [])

  const refresh = useCallback(() => setRefreshKey((k) => k + 1), [])

  const handleSubscribe = useCallback(
    (name: string, img: string, id: string) => {
      addSubscribedTipster(name, img, id)
      setShowSubscribeModal(name)
      refresh()
    },
    [refresh]
  )

  const handleViewProfile = useCallback((id: string) => {
    setShowProfile(id)
  }, [])

  const handleUnsubscribe = useCallback(
    (name: string) => {
      removeSubscribedTipster(name)
      setShowProfile(null)
      refresh()
      alert("Umemondoa " + name + " kwenye subscription yako.")
    },
    [refresh]
  )

  const handleViewBetslipsFromProfile = useCallback((id: string) => {
    setShowProfile(null)
    setActivePage("betslips")
    setTimeout(() => setShowDetail(id), 100)
  }, [])

  const handleUnlocked = useCallback((tipsterId: string) => {
    void tipsterId
    setUnlockKey((k) => k + 1)
  }, [])

  const handleNavigate = useCallback((page: Page) => {
    setActivePage(page)
  }, [])

  const handleLogout = useCallback(() => {
    logoutUser()
    setIsAuthenticated(false)
    setActivePage("home")
  }, [])

  const handleAuthenticated = useCallback(() => {
    setIsAuthenticated(true)
  }, [])

  if (showSplash) return <SplashScreen />
  if (!authChecked) return null
  if (!isAuthenticated) return <AuthScreen onAuthenticated={handleAuthenticated} />

  return (
    <div className="pb-[90px]">
      {/* Main Pages */}
      <div style={{ display: activePage === "home" ? "block" : "none" }}>
        <HomePage onSubscribe={handleSubscribe} onViewProfile={handleViewProfile} refreshKey={refreshKey} />
      </div>
      <div style={{ display: activePage === "betslips" ? "block" : "none" }}>
        <BetslipsPage
          onViewDetail={(id) => setShowDetail(id)}
          onShowHistory={() => setShowHistory(true)}
          onShowStats={() => setShowStats(true)}
        />
      </div>
      <div style={{ display: activePage === "subscription" ? "block" : "none" }}>
        <SubscriptionPage refreshKey={refreshKey} onRefresh={refresh} onViewProfile={handleViewProfile} />
      </div>
      <div style={{ display: activePage === "account" ? "block" : "none" }}>
        <AccountPage onShowPayment={() => setShowPaymentGeneral(true)} onLogout={handleLogout} />
      </div>

      <BottomNav activePage={activePage} onNavigate={handleNavigate} />

      {/* Overlays */}
      {showDetail && (
        <BetslipDetailPage
          tipsterId={showDetail}
          onBack={() => setShowDetail(null)}
          onBuy={(id) => setShowPayment(id)}
          unlockKey={unlockKey}
        />
      )}

      {showProfile && (
        <TipsterProfilePage
          tipsterId={showProfile}
          onBack={() => setShowProfile(null)}
          onUnsubscribe={handleUnsubscribe}
          onViewBetslips={handleViewBetslipsFromProfile}
        />
      )}

      {(showPayment || showPaymentGeneral) && (
        <PaymentPage
          tipsterId={showPayment}
          onClose={() => {
            setShowPayment(null)
            setShowPaymentGeneral(false)
          }}
          onUnlocked={handleUnlocked}
        />
      )}

      {showHistory && <HistoryPage onClose={() => setShowHistory(false)} />}
      {showStats && <StatisticsPage onClose={() => setShowStats(false)} />}

      {/* Subscribe Modal */}
      {showSubscribeModal && (
        <div
          className="fixed inset-0 flex items-center justify-center p-5"
          style={{ background: "rgba(0,0,0,0.85)", zIndex: 9999, backdropFilter: "blur(8px)" }}
        >
          <div
            className="text-center w-full"
            style={{
              maxWidth: 340,
              padding: 32,
              background: "linear-gradient(180deg, #1a1a1a, #0a0a0a)",
              borderRadius: 22,
              border: "1px solid rgba(93,206,168,0.15)",
            }}
          >
            <div
              className="flex items-center justify-center rounded-full mx-auto mb-5 text-4xl font-black"
              style={{
                width: 70,
                height: 70,
                background: "linear-gradient(135deg, #5DCEA8, #3aa37a)",
                color: "#000",
                boxShadow: "0 6px 20px rgba(93,206,168,0.4)",
              }}
            >
              &#10003;
            </div>
            <h3 className="text-[22px] font-extrabold mb-2.5" style={{ color: "#5DCEA8" }}>
              Umefanikiwa!
            </h3>
            <p className="text-[15px] mb-6 leading-relaxed" style={{ color: "#888" }}>
              Umesubscribe <strong className="text-white">{showSubscribeModal}</strong>. Sasa unaweza kuona profile yake.
            </p>
            <button
              onClick={() => setShowSubscribeModal(null)}
              className="rounded-xl text-base font-extrabold cursor-pointer transition-all duration-300 border-none"
              style={{ padding: "14px 40px", background: "linear-gradient(135deg, #5DCEA8, #3aa37a)", color: "#000" }}
            >
              Sawa
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
