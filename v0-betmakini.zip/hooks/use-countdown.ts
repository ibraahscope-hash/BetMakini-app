"use client"

import { useState, useEffect } from "react"

export function useCountdown(hours: number, mins: number, secs: number) {
  const [totalSeconds, setTotalSeconds] = useState(hours * 3600 + mins * 60 + secs)

  useEffect(() => {
    if (totalSeconds <= 0) return
    const interval = setInterval(() => {
      setTotalSeconds((prev) => {
        if (prev <= 0) {
          clearInterval(interval)
          return 0
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(interval)
  }, [totalSeconds])

  if (totalSeconds <= 0) return "Imeisha"

  const h = Math.floor(totalSeconds / 3600)
  const m = Math.floor((totalSeconds % 3600) / 60)
  const s = totalSeconds % 60
  return `${h}h ${m}m ${s}s`
}
