"use client"

export default function BetMakiniApp() {
  return (
    <iframe
      src="/betmakini.html"
      className="w-full h-screen border-0"
      title="BetMakini App"
    />
  )
}
